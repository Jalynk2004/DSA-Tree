#include<bits/stdc++.h>
using namespace std;
struct Node {
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int data) : data(data), left(nullptr), right(nullptr), height(1) {}
};

class AVLTree {
private:
    Node* root;

    Node* insertRecursive(Node* node, int data);
    int getHeightRecursive(Node* node);
    int getBalanceFactor(Node* node);
    Node* rotateLeft(Node* node);
    Node* rotateRight(Node* node);

public:
    AVLTree() : root(nullptr) {}

    void insert(int data);
    int getHeight();
};

Node* AVLTree::insertRecursive(Node* node, int data) {
    if (node == nullptr) {
        return new Node(data);
    }

    if (data < node->data) {
        node->left = insertRecursive(node->left, data);
    } else if (data > node->data) {
        node->right = insertRecursive(node->right, data);
    } else {
        // Duplicate keys are not allowed in AVL tree
        return node;
    }

    node->height = 1 + std::max(getHeightRecursive(node->left), getHeightRecursive(node->right));

    int balanceFactor = getBalanceFactor(node);

    // Perform rotations if the node becomes unbalanced
    if (balanceFactor > 1 && data < node->left->data) {
        return rotateRight(node);
    }
    if (balanceFactor < -1 && data > node->right->data) {
        return rotateLeft(node);
    }
    if (balanceFactor > 1 && data > node->left->data) {
        node->left = rotateLeft(node->left);
        return rotateRight(node);
    }
    if (balanceFactor < -1 && data < node->right->data) {
        node->right = rotateRight(node->right);
        return rotateLeft(node);
    }

    return node;
}

int AVLTree::getHeightRecursive(Node* node) {
    if (node == nullptr) {
        return 0;
    }

    return node->height;
}

int AVLTree::getBalanceFactor(Node* node) {
    if (node == nullptr) {
        return 0;
    }

    return getHeightRecursive(node->left) - getHeightRecursive(node->right);
}

Node* AVLTree::rotateLeft(Node* node) {
    Node* newRoot = node->right;
    Node* subtree = newRoot->left;

    newRoot->left = node;
    node->right = subtree;

    node->height = 1 + std::max(getHeightRecursive(node->left), getHeightRecursive(node->right));
    newRoot->height = 1 + std::max(getHeightRecursive(newRoot->left), getHeightRecursive(newRoot->right));

    return newRoot;
}

Node* AVLTree::rotateRight(Node* node) {
    Node* newRoot = node->left;
    Node* subtree = newRoot->right;

    newRoot->right = node;
    node->left = subtree;

    node->height = 1 + std::max(getHeightRecursive(node->left), getHeightRecursive(node->right));
    newRoot->height = 1 + std::max(getHeightRecursive(newRoot->left), getHeightRecursive(newRoot->right));

    return newRoot;
}

void AVLTree::insert(int data) {
    root = insertRecursive(root, data);
}

int AVLTree::getHeight() {
    return getHeightRecursive(root);
}
int main()
{
     ofstream fo("AVLHeight.txt"); // Output file
     for (int f = 1; f <= 10; ++f) {
            AVLTree avl;
         ifstream fi("./Data" + to_string(f) +".txt"); // Input file
         int n; fi >> n;
         // Add value in input file into AVLTree
         for (int i = 0 ; i < n; ++i) {
             int a; fi >> a; avl.insert(a);
         }
         fo <<avl.getHeight() <<'\n';
     }
}

