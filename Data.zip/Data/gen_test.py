import numpy as np
import json

# Tạo mảng ngẫu nhiên với 1 triệu phần tử
data = np.random.random_integers(0, 1000000000, 1000000)


print(data[:])

for i in range(1, 11):
    with open(f'./Data/Data{i}.txt', 'w') as filehandle:
        json.dump(data.tolist(), filehandle)
